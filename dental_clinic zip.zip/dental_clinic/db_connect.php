<?php
$servername = "localhost"; // Database server
$username = "root"; // Your database username (default is usually 'root')
$password = ""; // Your database password (default is usually empty for local servers)
$dbname = "my_website"; // The name of the database you created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

// Close the connection when done (optional)
// $conn->close();
?>
