<?php
// Include your database connection file
include 'db_connection.php';

// Query to fetch data from your table
$sql = "SELECT * FROM your_table_name"; // Replace with your table name
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th></tr>"; // Adjust headers as needed
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"] . "</td><td>" . $row["name"] . "</td><td>" . $row["email"] . "</td></tr>"; // Adjust columns as needed
    }
    echo "</table>";
} else {
    echo "0 results";
}

// Close the connection
$conn->close();
?>
