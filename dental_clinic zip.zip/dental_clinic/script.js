 
 let menu = document.querySelector('#menu-btn');
 let navbar = document.querySelector('.header .nav');
 let header = document.querySelector('.header');

 menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
 }

 window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');

   if(window.scrollY > 0){
      header.classList.add('active');
   }else{
      header.classList.remove('active');
   }

 }


  let slideImages = document.querySelectorAll('img');
  let next = document.querySelector('.next');
  let prev = document.querySelector('.prev');
  let dots = document.querySelectorAll('.dot');
 
  let counter = 0;

  next.addEventListener('click', slideNext);
  function slideNext(){
   slideImages[counter].style.animation = 'next1 0.5s ease-in forwards';
   
    if (counter >= slideImages.length-1){
       counter = 0;
    }
    else{
       counter++;
    }
    slideImages[counter].style.animation = 'next2 0.5s ease-in forwards';
   }
   
  
  prev.addEventListener('click' , slidePrev);
  function slidePrev(){
   slideImages[counter].style.animation = 'prev1 0.5s ease-in forwards';
   if (counter == 0){
      counter = slideImages.length-1 ;
   }
   else{
      counter--;
   }
   slideImages[counter].style.animation = 'prev2 0.5s ease-in forwards';
  }


  function autoSliding(){
   deletInterval = setInterval(timer, 2000);
   function timer(){
      slideNext();
      indicators();
   }
  }
  autoSliding();

  const container = document.querySelectorAll('.slide-container');
  container.addEventListener('mouseover', function(){
      clearInterval(deletInterval);
  });


  container.addEventListener('mouseout', autoSliding);

  function indicators(){
   for(i = 0; i< dots.length; i++){
      dots[i].classsName = dots[i].className.replace('active', '');
   }
   dots[container].className += 'active';
  }
  
  function switchImage(currentImage) {
   currentImage.classList.add('active');
   let imageId = currentImage.getAttribute('attr');
   if(imageId > counter){
   slideImages[counter].style.animation = 'next1 0.5s ease-in forwards';
   counter = imageId;
   slideImages[counter].style.animation = 'next2 0.5s ease-in forwards';
   }
   else if(imageId == counter){
   return;
   }
    else{
   slideImages[counter].style.animation = 'prev1 0.5s ease-in forwards';
   counter = imageId;
   slideImages[counter].style.animation = 'prev2 0.5s ease-in forwards';

    }
    indicators();
  }
